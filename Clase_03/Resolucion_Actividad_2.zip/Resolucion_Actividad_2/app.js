const app = Vue.createApp({
    data(){  // Simil a los atributos de una clase
        return {
            nombre: 'Micaela',
            foto: 'img/micaela.png',
            saldo: 20000,
            visible: false,
            transacciones : transacciones
        }
    }
    // Methods
});


app.mount('#app');

