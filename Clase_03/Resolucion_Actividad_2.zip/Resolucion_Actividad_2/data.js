const transacciones = [
    { id:1, valor: 12000, fecha: '05-08-24'},
    { id:2, valor: -20000, fecha: '01-08-24'},
    { id:3, valor: 5000, fecha: '01-07-24'},
    { id:4, valor: -7000, fecha: '20-08-24'},
    { id:5, valor: 25000, fecha: '21-08-24'},
]